<?php
$_['heading_title'] = 'Пример модуля';
$_['text_example']  = 'Пример модуля на OpenCart 3.x';
$_['text_error']    = 'Модуль выключен';
?>